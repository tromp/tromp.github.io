// combinator K applied to one argument
class ApplicationKM extends Application
{
  public ApplicationKM(Combination arg)
  {
    super(Combinator.K, arg);
  }

  // implements apply of Combination
  public Combination apply(Combination a)
  {
    steps++;
    return arg.headNormalForm();
  }

  // overrides makeApplication of Combination, which is needed because
  // ApplicationKM applied to arg is head reducible
  // however, we perform the trivial effort of reducing KMN to M,
  // to avoid constructing a new ApplicationDelay
  public Combination makeApplication(Combination a, boolean mutable)
  {
    steps++;
    return arg;
  }
}
