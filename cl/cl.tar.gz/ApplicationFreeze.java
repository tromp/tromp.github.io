// immutable application of M to N (where MN is generally head reducible)
class ApplicationFreeze extends Application
{
  public ApplicationFreeze(Combination fun, Combination arg)
  {
    super(fun, arg);
  }

  // implements apply of Combination
  public Combination apply(Combination a)
  {
    return headNormalForm().apply(a);
  }

  // overrides makeApplication of Combination, which is needed because
  // ApplicationFreeze applied to arg is head reducible
  public Combination makeApplication(Combination a, boolean mutable)
  {
    if (mutable) return new ApplicationDelay(this, a);
    return new ApplicationFreeze(this, a);
  }

  // overrides headNormalForm of Combination, which is needed because
  // ApplicationFreeze is head reducible
  public Combination headNormalForm()
  {
    return fun.apply(arg);
  }
}
