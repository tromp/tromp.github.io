import java.util.*;
import java.io.*;

// a character based Combinatory Logic environment
class CL
{
  // maps single character names to user defined combinations
  Hashtable defs;

  public CL()
  {
    defs = new Hashtable();
    String[] initdefs = {
      "Sxyz=xz(yz)",			// S
      "Kxy=x",				// K
      "Ix=x",				// identity I

      "Pxyz=zxy",			// pairing combinator  (cons)
      "Y=SSK(S(K(SS(S(SSK))))K)",	// fix-point combinator Yx=x(Yx)
// recursive defs must come here after definition of Y

// CL interpreter
      "?x=qx(xSK)",
      "0l=l?",
      "1xy=xy(Sx(Sy))",
      "?xy=yx",
      "$q=?(S(?0)(K(1(Ku)q)))",
      "?uc=$(Kc)",
      "U=Y?I",

// LC interpreter
      "1f=c(Sef)",
      "0ab=e(Pba)",
      "?e=d(c0)(v1)",
      "0a=e(a(SK))",
      "1e=c0",
      "$d=b(v?)(d(c(SI(KK)))(K(v1r)))",
      "0br=r$",
      "1vcl=l0",
      "L=Y1(SS(SK))",

      "?x=qx(xSK)",
      "0l=l?",
      "1xy=xy(Sx(Sy))",
      "?xy=yx",
      "$q=?(S(?0)(K(1(Ku)q)))",
      "?uc=$(Kc)",
      "U=Y?I",

// 0, 1, ?, and $ are first used to help define U
// and finally redefined; keep these defs ordered
      "0xy=x",				// true; bit 0
      "1xy=y",				// false; bit 1
      "?l=l(K(KS))0",			// test for empty list
      "$=1",				// empty list
    };

    for (int i=0; i<initdefs.length; i++)
      AddDef(initdefs[i]);
  }

  // lookup a combination by name; if not found, add its definition as variable
  public Combination lookup(char c)
  {
    Combination x;
    Character wrapc = new Character(c);

    x = (Combination)defs.get(wrapc);
    if (x == null) {
      x = new Variable((int)c);
      defs.put(wrapc, x);
    }
    return x;
  }

  // lookup a combination by name; if not found, add its definition as variable
  public boolean unified(Variable v, Combination x)
  {
    Character wrapv = new Character((char)v.index);

    Combination y = (Combination)defs.get(wrapv);
    if (y == v) {
      defs.put(wrapv, x);
      return true;
    }
    return x == y;
  }

  // add a name->combination mapping
  public void map(char c, Combination x)
  {
    defs.put(new Character(c), x);
  }

  // effectively remove a mapping
  public Variable unmap(char c)
  {
    Variable var = new Variable((int)c);
    defs.put(new Character(c), var);
    return var;
  }

  // build a list of bits encoding string s, terminated with x
  // encodes name free lambda calculus expressions
  public Combination prefixBinary(String s, Combination x)
  {
    int i;

    // s = s.replace('^','\\').replace('@','`'));
    while ((i = s.indexOf('\\')) >= 0) {
      int start = s.indexOf('`');
      if (start < 0 || i < start)
        start = i;
      StringBuffer code = new StringBuffer();
      int end = parseLambda(s, start, "", code);
      s = s.substring(0,start) + code + s.substring(end);
    }
    for (i = s.length()-1; i >= 0; i--) {
      char c = s.charAt(i);
      if (c == '0' || c == '1')
        x = lookup('P').apply(lookup(c)).apply(x);
      else x = prefixBinary(lookup(c).toBinaryString(), x);
    }
    return x;
  }

  public int parseLambda(String s, int i, String vars, StringBuffer t)
  {
    char c;
    while ((c = s.charAt(i)) == ' ')
      i++;
    if (c == '\\') {
      t.append("00");
      return parseLambda(s, i+2, s.substring(i+1,i+2)+vars, t);
    } else if (c == '`') {
      t.append("01");
      return parseLambda(s, parseLambda(s, i+1, vars, t), vars, t);
    } else {
      int j=vars.indexOf(c);
      if (j == -1)
        throw new RuntimeException("Unbound variable "+c+" in lambda expression");
      for (; j>=0; j--)
        t.append("1");
      t.append("0");
      return i+1;
    }
  }

  // parse a string for a combination
  // combination can be made immutable, as used in definitions
  public Combination parse(String s, boolean mutable)
  {
    int i,j;
    char c;
    Combination x = null;
    Combination y;

    for (i = 0; i < s.length(); i++)
    {
      c = s.charAt(i);
      if (Character.isWhitespace(c))
        continue;
      if (c == '(') {
        j = matchPar(s, i);
        y = parse(s.substring(i+1, j), mutable);
        i = j;
      } else if (c == '"') {
        j = s.indexOf('"', i+1);
        if (j < 0)
          throw new RuntimeException("unmatched \"");
         y = prefixBinary(s.substring(i+1, j), lookup('$'));
        i = j;
      } else if (c == ')') {
        throw new RuntimeException("unmatched )");
      } else y = lookup(c);
      if (x == null)
        x = y;
      else x = x.makeApplication(y, mutable);
    }
    return x;
  }

  // return position of matching ')', given a '(' in position i
  static int matchPar(String s, int i)
  {
    char c;

    try {
      while ((c = s.charAt(++i)) != ')') {
        if (c == '(')
          i = matchPar(s, i);
      }
      return i;
    } catch (IndexOutOfBoundsException e) {
      throw new RuntimeException("unmatched (");
    }
  }

  // add a, possibly recursive, definition given in a string
  public Combination AddDef(String s)
  {
    Combination x;
    boolean recursive;
    int i, var;
    char name;

    name = s.charAt(0);
    i = s.indexOf('=',1);
    recursive = (s.indexOf(name,i+1) >= 0);
    if (recursive)
      unmap(name);
    x = parse(s.substring(i+1), false);
    if (x == null)
      return unmap(name);
    for (int j = i-1; j>0; j--) {
      var = (int)s.charAt(j);
      x = x.bracketAbstract(var);
    }
    if (recursive) {
      var = (int)name;
      x = lookup('Y').makeApplication(x.bracketAbstract(var), false);
    }
    map(name, x);
    return x;
  }

// changes lookup() entries to store unification assignments
  public boolean unify(Combination x, Combination y)
  {
    if (y instanceof CombinatorS) {
      //if (x instanceof ApplicationSMN) {
        //if ((xz=x.apply(varz)) instanceof ApplicationSM && 
          //((ApplicationSM)xz).arg == varz)
        //return true;
      //}
      return (x instanceof CombinatorS);
    }
    if (y instanceof CombinatorK) {
      //if (x instanceof ApplicationSMN) {
        //if ((xz=x.apply(varz)) instanceof ApplicationKM && 
          //((ApplicationKM)xz).arg == varz)
        //return true;
      //}
      return (x instanceof CombinatorK);
    }
    if (y instanceof Variable) {
      return unified(((Variable)y), x);
    }
    // must be Application
    if (!(x instanceof Application && y instanceof Application))
      return false;
    return unify(((Application)x).fun,((Application)y).fun) &&
           unify(((Application)x).arg.headNormalForm(),
                 ((Application)y).arg.headNormalForm());
  }

  // interpret combination as a binary string,
  // i.e. see if x has the same headNormalForm
  //      as P s_0 (P s_1 ( ... ( P s_{n-1} $) ... ) )
  // return either a string s_0 s_1 s_{n-1} or the Combination where
  // binary string interpretation fails.
  public Object output(Combination x)
  {
    StringBuffer outbits;
    Combination y, SK, Pyx;
    Variable varx, vary;

    SK = parse("SK", true);
    varx = (Variable)lookup('x');
    vary = (Variable)lookup('y');
    Pyx = parse("Pyx", true).headNormalForm();

    outbits = new StringBuffer();
    for (;;) {
// x could be empty, i.e. sk
      if (unify(x, SK))
        return outbits.toString();
// x could be a pair, i.e. PMN
      else if (unify(x, Pyx)) {
        x = lookup('x');
        y = lookup('y');
        map('x', varx);
        map('y', vary);
        if (unify(y, lookup('0')))
          outbits.append('0');		// x0 = K
        else if (unify(y, lookup('1')))
          outbits.append('1');		// x0 = SK
        else return x;
      } else return x;
    }
  }

  // a more aggressive output interpreter
  public Object output2(Combination x)
  {
    StringBuffer outbits;
    Combination y, SK;
    Variable varx, vary;

    SK = parse("SK", true);
    varx = new Variable(0);
    vary = new Variable(1);

    outbits = new StringBuffer();
    for (;;) {
      y = lookup('?').apply(x).apply(varx).apply(vary);
// x could be empty, i.e. ?x==true
      if (y == varx)
        return outbits.toString();
// x could be a pair, i.e. ?x==false
      else if (y == vary) {
        y = x.apply(lookup('0')).apply(varx).apply(vary);
        x = x.apply(lookup('1'));
        if (y==varx)
          outbits.append('0');		// x0 = K
        else if (y==vary)
          outbits.append('1');		// x0 = SK
        else outbits.append('*');
      } else return x;
    }
  }

  // command line interpreter
  public static void main(String args[])
  {
    int printDepth=9;
    int i,size;
    Combination x;     // to stop compiler complaining
    ApplicationDelay ad;
    BufferedReader dis = new BufferedReader(new InputStreamReader(System.in));
    String line;
    long steps;
    boolean definition;
    Character c;
    CL cl = new CL();

    System.out.println("At the prompt, enter a combination or a definition");
    System.out.println("Names are single characters; whitespace is ignored");
    System.out.println("An empty definition like \"P=\" undefines a name");
    System.out.println("Predefined names are");
    for (Enumeration e = cl.defs.keys(); e.hasMoreElements(); ) {
      c = (Character)e.nextElement();
      x = (Combination)cl.defs.get(c);
      if (!(x instanceof Variable))
        System.out.print(" " + c);
    }
    System.out.println("\nExample inputs are: Sxyz, U\"I110\", 2fx=f(fx), Z=222(P0), U\"Z\"");
    for (;;) {
      System.out.print("> ");
      System.out.flush();
      try {
        do {
          line = dis.readLine();
        } while (line.length() == 0);
        while (line.charAt(line.length()-1) == '\\')
          line = line.substring(0, line.length()-1) + dis.readLine();
      } catch (Exception e) {
        break;
      }
      // make significance of spaces apparent
      line = line.trim();
      definition = (line.indexOf('=',1) >= 0);
      if (definition) {
        if (line.startsWith("depth=")) {
          printDepth = Integer.parseInt(line.substring(6));
          continue;
        }
        try {
          x = cl.AddDef(line);
        } catch (Exception e) {
          System.out.println(e);
          continue;
        }
        System.out.println("defines " + line.charAt(0) + " as "
                           + x.toDepthString(printDepth));
        System.out.println("of size " + x.size());
        continue;
      }
      try {
      x = cl.parse(line, true); // mutable
      } catch (Exception e) {
        System.out.println(e);
        continue;
      }
      System.out.println("of size " + x.size());
      steps = Combination.steps;

      x = x.headNormalForm();
      steps = Combination.steps - steps;
      System.out.println("head reduces in " + steps + " steps to "
                         + x.toDepthString(printDepth) + " of size " + x.size());
      try {
        String o = (String)cl.output2(x);
        System.out.println("outputs " + o.length() + " bits " + '"' + o + '"');
      } catch (Exception e) {}
    }
  }
}
