// variables x0, x1, ..., some printed as an ascii letter
class Variable extends Combination
{
  // each variable is identified by an integer
  int index;

  public Variable(int i)
  {
    index = i;
  }

  // implements size of Combination
  public int size()
  {
    return 1;
  }

  // implements apply of Combination
  public Combination apply(Combination a)
  {
    return new ApplicationVarHead(this, a);
  }

  // implements containsVariable of Combination
  boolean containsVariable(int i)
  {
    return i == index;
  }

  // implements containsVariableOtherThan of Combination
  boolean containsVariableOtherThan(int i)
  {
    return i != index;
  }

  // implements containsVariable of Combination
  boolean containsVariable()
  {
    return true;
  }

  // implements occursAbstract of Combination
  // implements occursAbstract of Combination
  Combination occursAbstract(int i)
  {
    return Combinator.I;
  }

  // overrides toString of Combination
  // a variable is printed as an ascii letter if possible
  // or as "x" + index otherwise
  public String toString()
  {
    if (Character.isISOControl((char)index))
      return "x" + index;
    return String.valueOf((char)index);
  }

  // overrides toDepthString of Combination
  public String toDepthString(int d)
  {
    return toString();
  }
}
