// abstract root class of all applications, defining common functionality
abstract class Application extends Combination
{
  Combination fun;
  Combination arg;
  int size;

  public Application(Combination fun, Combination arg)
  {
    this.fun = fun;
    this.arg = arg;
    size = fun.size() + arg.size();
  }

  // implements size of Combination
  public int size()
  {
    return size;
  }

  // implements containsVariable of Combination
  boolean containsVariable(int d)
  {
    return  fun.containsVariable(d) || arg.containsVariable(d);
  }

  // implements containsVariableOtherThan of Combination
  boolean containsVariableOtherThan(int d)
  {
    return  fun.containsVariableOtherThan(d)||arg.containsVariableOtherThan(d);
  }

  // implements containsVariable of Combination
  boolean containsVariable()
  {
    return  fun.containsVariable() || arg.containsVariable();
  }

  // implements occursAbstract of Combination
  // suppose X contains variable i
  // whereas M,N don't contain any variable
  // then we translate M(N(X)) to S(KM)NX
  // and translate MXN to SM(KN)X
  // to bring other variables in X closer to top
  // seems equivalent to using Turner's B and C combinators,
  // but without their overhead.
  Combination occursAbstract(int i)
  {
    if (!fun.containsVariable(i)) {
      if (arg instanceof Variable)
        return fun;
      if (!fun.containsVariable()) {
if (!(arg instanceof Application))
throw new RuntimeException("arg is not an App " + arg);
        Application apparg = (Application)arg;
        Combination N = apparg.fun;
        if (!N.containsVariable()) //&& apparg.arg.containsVariableOtherThan(i))
          return Combinator.S.apply(Combinator.K.apply(fun)).apply(N).
                 makeApplication(apparg.arg, false).occursAbstract(i);
      }
    } else if (!arg.containsVariable() && fun instanceof Application) {
      Application appfun = (Application)fun;
      Combination M = appfun.fun;
      if (!M.containsVariable()) //&& appfun.arg.containsVariableOtherThan(i))
        return Combinator.S.apply(M).apply(Combinator.K.apply(arg)).
                 makeApplication(appfun.arg, false).occursAbstract(i);
    }
    return Combinator.S.apply(fun.bracketAbstract(i)).apply(arg.bracketAbstract(i));
  }

  // overrides toString of Combination
  public String toString()
  {
    return fun.toString()+(arg instanceof Application ?
      "(" + arg + ")" : arg.toString());
  }

  // overrides toPosDepthString of Combination
  String toPosDepthString(int i)
  {
    return fun.toDepthString(i - 1)+(arg instanceof Application ?
      "(" + arg.toDepthString(i - 1) + ")" : arg.toDepthString(i - 1) );
  }

  // overrides toBinaryString of Combination
  public String toBinaryString()
  {
    return "1" + fun.toBinaryString() + arg.toBinaryString();
  }
}
