// mutable application of M to N (where MN is generally head reducible)
class ApplicationDelay extends ApplicationFreeze
{
  Combination hnf = null;

  public ApplicationDelay(Combination fun, Combination arg)
  {
    super(fun, arg);
  }

  // overrides headNormalForm of ApplicationFreeze
  // so as to re-use the hnf
  public Combination headNormalForm()
  {
    if (hnf == null) {
      hnf = super.headNormalForm();
      size = hnf.size();
    }
    return hnf;
  }

  // overrides toString of Combination
  public String toString()
  {
    return (hnf != null ? hnf.toString() : super.toString());
  }

  // overrides toPosDepthString of Combination
  public String toPosDepthString(int d)
  {
    return hnf != null ? hnf.toDepthString(d)
                       : super.toPosDepthString(d);
  }

  // overrides toBinaryString of Combination
  public String toBinaryString()
  {
    return (hnf != null ? hnf.toBinaryString() : super.toBinaryString());
  }
}
