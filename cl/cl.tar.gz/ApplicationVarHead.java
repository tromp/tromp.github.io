// application with variable at its head
class ApplicationVarHead extends Application
{
  public ApplicationVarHead(Combination fun, Combination arg)
  {
    super(fun, arg);
  }

  // implements apply of Combination
  public Combination apply(Combination a)
  {
    return new ApplicationVarHead(this, a);
  }
}
