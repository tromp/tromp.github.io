// combinator S applied to two arguments
class ApplicationSMN extends Application
{
  public ApplicationSMN(ApplicationSM sm, Combination arg)
  {
    super(sm, arg);
  }

  // implements abstract apply of Combination
  public Combination apply(Combination a)
  {
    steps++;
    return ((ApplicationSM)fun).arg.apply(a).apply(arg.makeApplication(a,true));
  }

  // overrides makeApplication of Combination, which is needed because
  // ApplicationSMN applied to arg is head reducible
  public Combination makeApplication(Combination a, boolean mutable)
  {
    if (mutable) return new ApplicationDelay(this, a);
    return new ApplicationFreeze(this, a);
  }

  // overrides bracketAbstract of Combination
  // note that I = SKx for any x
  public Combination bracketAbstract(int var)
  {
    return ((ApplicationSM)fun).arg instanceof CombinatorK ?
      Combinator.SK :
      super.bracketAbstract(var);
  }

}
