// variable-free combinations; need only be instantiated once
abstract class Combinator extends Combination
{
  static CombinatorS S = new CombinatorS();
  static CombinatorK K = new CombinatorK();
  static ApplicationSM SK = (ApplicationSM)Combinator.S.apply(Combinator.K);
  static ApplicationSMN I = (ApplicationSMN)Combinator.SK.apply(Combinator.K);

  // implement containsVariable of Combination
  boolean containsVariable(int var)
  {
    return false;
  }

  // implement containsVariableOtherThan of Combination
  boolean containsVariableOtherThan(int var)
  {
    return false;
  }

  // implement containsVariable of Combination
  boolean containsVariable()
  {
    return false;
  }

  // implement occursAbstract of Combination
  // implement occursAbstract of Combination
  // this method should never be invoked, since a combinator
  // is variable-free
  Combination occursAbstract(int var)
  {
    throw new RuntimeException("Combinator doesn't occursAbstract");
  }

  // overrides bracketAbstract of Combination
  public Combination bracketAbstract(int var)
  {
    return new ApplicationKM(this);
  }

  // overrides toDepthString of Combination
  public String toDepthString(int d)
  {
    return toString();
  }
}
