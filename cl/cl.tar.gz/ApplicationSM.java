// combinator S applied to one argument
class ApplicationSM extends Application
{
  public ApplicationSM(Combination arg)
  {
    super(Combinator.S, arg);
  }

  // implements abstract apply of Combination
  public Combination apply(Combination a)
  {
    return new ApplicationSMN(this, a);
  }
}
