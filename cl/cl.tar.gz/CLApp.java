import java.applet.Applet;
import java.util.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;

public class CLApp extends Applet implements ActionListener
{
  TextField in;
  TextArea out;
  Character c;
  Combination x;
  CL cl;

  public void init()
  {
    setLayout(new BorderLayout());
    cl = new CL();
    in = new TextField(80);
    in.addActionListener(this);
    add(in, "South");
    out = new TextArea(12,80);
    out.setEditable(false);
    add(out,"Center");
    out.append("Enter a combination or a definition.\n");
    out.append("Names are single characters; whitespace is ignored\n");
    out.append("An empty definition like \"P=\" undefines a name\n");
    out.append("Predefined names are\n");
    for (Enumeration e = cl.defs.keys(); e.hasMoreElements(); ) {
      c = (Character)e.nextElement();
      x = (Combination)cl.defs.get(c);
      if (!(x instanceof Variable))
        out.append(" " + c);
    }
    out.append("\nExample inputs are: Sxyz, U\"I110\", 2fx=f(fx), Z=222(P0), U\"Z\"");
  }

  public void actionPerformed(ActionEvent evt)
  {
    int i,size,column;
    Combination x=null;     // to stop compiler complaining
    String line;
    Thread t;
    ApplicationDelay ad;
    boolean definition;
    long steps;

     try {
      line = in.getText();
      if (line.length() == 0)
        return;
      // make significance of spaces apparent
      line = line.trim();
      definition = (line.indexOf('=',1) >= 0);
      out.append("\n" + line + "\n");
      if (definition) {
        try {
          x = cl.AddDef(line);
        } catch (Exception e) {
          out.append(e.toString());
          out.append("Oops, try again...\n");
          return;
        }
        out.append("defines " + line.charAt(0) + " as "
                   + x.toDepthString(5) + " of size " + x.size());
        in.setText("");
        return;
      }
      try {
      x = cl.parse(line, true); // no definition
      } catch (Exception e) {
        out.append(e.toString());
        return;
      }
      out.append("of size " + x.size());
      steps = Combination.steps;
      x = x.headNormalForm();
      steps = Combination.steps - steps;
      out.append("\nhead reduces in " + steps + " steps to "
                         + x.toDepthString(5) + " of size " + x.size());
      try {
        String o = (String)cl.output(x);
        out.append("\noutputs " + o.length() + " bits \"");
        while (o.length() > 64) {
          out.append(o.substring(0,64) + "\n");
          o = o.substring(64);
        }
        out.append(o + "\"\n");
      } catch (Exception e) { }
      in.setText("");
     } finally {
      size = out.getText().length() - 1;
      out.select(size, size);    // stupid TextArea doesn't autoscroll...
     }
  }
}
