// abstract root class of all combinations, defining common functionality
abstract class Combination
{
  public static long steps = 0;	// counts reduction steps

  // returns head normal form (hnf) of a combination
  // where I define a combination to be in hnf if it's not head-reducible.
  // since many combinations are already in hnf, we can usually just
  // return `this'. combinations that are head-reducible *MUST* override
  // this method
  public Combination headNormalForm()
  {
    return this;	// override if the combination is not already in hnf!
  }

  // size in number of atomic combinators (S and K)
  // if not fixed, will be stored in a field
  public abstract int size();

  // returns head normal form of `this' applied to arg
  public abstract Combination apply(Combination arg);

  // returns an application, possibly mutable.
  // since many combinations are not head-reducible, apply()
  // usually constructs the application we want. if apply does a non-trivial
  // amount of reduction though, then this method *MUST* be overridden
  public Combination makeApplication(Combination arg, boolean mutable)
  {
    return apply(arg);
  }

  // does the combination have an occurance of the given variable?
  abstract boolean containsVariable(int var);

  // does the combination have any variable occurance?
  abstract boolean containsVariable();

  // does the combination have any other variable occurance?
  abstract boolean containsVariableOtherThan(int var);

  // return bracket abstraction of this combination for given variable
  public Combination bracketAbstract(int var)
  {
    return containsVariable(var)? occursAbstract(var): new ApplicationKM(this);
  }

  // bracket abstraction given that the variable occurs
  abstract Combination occursAbstract(int var);

  // print combination in standard way, with possibly redundant parentheses
  public String toString()
  {
    throw new RuntimeException(getClass().getName() + " can't toString()");
  }

  // depth limited printing
  public String toDepthString(int d)
  {
    return d <= 0 ? "*" : toPosDepthString(d);
  }

  // positive-depth limited printing
  String toPosDepthString(int d)
  {
    throw new RuntimeException(getClass().getName() +
      " can't toPosDepthString()");
  }

  // binary encoding of combinators
  public String toBinaryString()
  {
    throw new RuntimeException(getClass().getName() +
      " can't toBinaryString()");
  }
}
