// `konstant' combinator Kxy=x
class CombinatorK extends Combinator
{
  // implements size of Combination
  public int size()
  {
    return 1;
  }

  // implements abstract apply of Combination
  public Combination apply(Combination arg)
  {
    return new ApplicationKM(arg);
  }

  // overrides toString of Combination
  public String toString()
  {
    return "K";
  }

  // overrides toBinaryString of Combination
  public String toBinaryString()
  {
    return "01";
  }
}
