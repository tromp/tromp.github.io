// composition combinator Sxyz=xz(yz)
class CombinatorS extends Combinator
{
  // implements size of Combination
  public int size()
  {
    return 1;
  }

  // implements abstract apply of Combination
  public Combination apply(Combination arg)
  {
    return new ApplicationSM(arg);
  }

  // overrides toString of Combination
  public String toString()
  {
    return "S";
  }

  // overrides toBinaryString of Combination
  public String toBinaryString()
  {
    return "00";
  }
}
